# Hamburgueria Starter
Projeto starter Next.js + TypeScript + Tailwind para sua hamburgueria.

Scripts:
- `npm install` to install deps
- `npm run dev` to start dev server
